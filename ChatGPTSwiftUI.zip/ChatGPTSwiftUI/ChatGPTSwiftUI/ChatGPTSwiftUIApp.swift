//
//  ChatGPTSwiftUIApp.swift
//  ChatGPTSwiftUI
//
//  Created by Xcode Developer on 11/28/23.
//

import SwiftUI

@main
struct ChatGPTSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
